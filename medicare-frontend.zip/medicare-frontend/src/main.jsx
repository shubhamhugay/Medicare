import React from "react";

import ReactDOM from "react-dom/client";

import {
    RouterProvider
} from "react-router/dom";

import "bootstrap/dist/css/bootstrap.min.css";

import "bootstrap/dist/js/bootstrap.bundle.min.js";

import "./index.css";

import router from "./routes/router";

import {
    AuthProvider
} from "./context/AuthContext";


ReactDOM
    .createRoot(
        document.getElementById(
            "root"
        )
    )
    .render(

        <React.StrictMode>

            <AuthProvider>

                <RouterProvider
                    router={
                        router
                    }
                />

            </AuthProvider>

        </React.StrictMode>
    );